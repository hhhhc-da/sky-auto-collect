# sky_human > Person v1
https://universe.roboflow.com/nanoka/sky_human

Provided by a Roboflow user
License: CC BY 4.0

